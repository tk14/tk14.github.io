These are skeletons, configuration is read from ~/.config/znt/*
